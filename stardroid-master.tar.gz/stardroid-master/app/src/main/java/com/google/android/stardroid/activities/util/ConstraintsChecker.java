package com.google.android.stardroid.activities.util;

import javax.inject.Inject;

/**
 * Created by johntaylor on 6/11/16.
 */
public class ConstraintsChecker {
  @Inject
  ConstraintsChecker() {
  }

  public boolean check() {
    return true;
  }
}
