#!/bin/bash

protoc --java_out="../../../../../../" source.proto
