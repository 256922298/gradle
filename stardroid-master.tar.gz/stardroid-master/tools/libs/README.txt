TODO(serafini): We need to move these two libraries to third_party at some 
point.
