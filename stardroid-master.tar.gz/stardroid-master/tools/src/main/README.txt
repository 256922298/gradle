TODO(serafini): We should move this code to a better place in the tree. 
Perhaps a tools directory?
